(function () {
  "use strict";

  if (window.__sentinelInjected) return;
  window.__sentinelInjected = true;

  const SENTINEL_TIMEOUT_MS = 15000;

  const pendingRequests = new Map();
  let requestIdCounter = 0;

  function postIntercept(type, data) {
    window.postMessage({ source: "sentinel-injected", type, ...data }, "*");
  }

  /**
   * TRUE BLOCKING: hold ANY wallet call until Sentinel API approves or denies.
   * Timeout 15s → passthrough (failsafe for offline API).
   */
  function waitForSentinelDecision(requestId) {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        pendingRequests.delete(requestId);
        resolve({ approved: true, reason: "timeout-passthrough" });
      }, SENTINEL_TIMEOUT_MS);

      pendingRequests.set(requestId, {
        resolve: (result) => {
          clearTimeout(timer);
          pendingRequests.delete(requestId);
          resolve(result);
        },
        reject: (err) => {
          clearTimeout(timer);
          pendingRequests.delete(requestId);
          reject(err);
        },
      });
    });
  }

  // Listen for decisions sent back by content.js
  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    if (!event.data || event.data.source !== "sentinel-content") return;

    const { requestId, approved, reason } = event.data;
    const pending = pendingRequests.get(requestId);
    if (!pending) return;

    if (approved) {
      pending.resolve({ approved: true, reason });
    } else {
      pending.reject(new Error("CipherGate blocked: " + (reason || "Policy violation")));
    }
  });

  // ─────────────────────────────────────────────
  //  SOLANA HELPERS
  // ─────────────────────────────────────────────

  /**
   * Extract useful metadata from a Solana Transaction or VersionedTransaction.
   * We cannot import @solana/web3.js here, so we read raw properties.
   */
  function extractSolanaInfo(transaction) {
    try {
      // VersionedTransaction (new format): message.compiledInstructions
      if (transaction && transaction.message && transaction.message.compiledInstructions) {
        const msg = transaction.message;
        const keys = msg.staticAccountKeys || [];
        const ixs = msg.compiledInstructions || [];
        const firstIx = ixs[0];
        const programIdx = firstIx ? firstIx.programIdIndex : null;
        const programId = programIdx != null && keys[programIdx]
          ? (keys[programIdx].toString ? keys[programIdx].toString() : String(keys[programIdx]))
          : null;
        return {
          programId,
          txType: ixs.length > 1 ? "multi_instruction" : "solana_tx",
          chain: "solana",
        };
      }

      // Legacy Transaction: .instructions[]
      if (transaction && Array.isArray(transaction.instructions)) {
        const ixs = transaction.instructions;
        const firstIx = ixs[0];
        const programId = firstIx && firstIx.programId
          ? (firstIx.programId.toString ? firstIx.programId.toString() : String(firstIx.programId))
          : null;
        return {
          programId,
          txType: ixs.length > 1 ? "multi_instruction" : "solana_tx",
          chain: "solana",
        };
      }
    } catch (_) {}

    return { programId: null, txType: "solana_tx", chain: "solana" };
  }

  /**
   * Serialize a Solana Transaction or VersionedTransaction to a base64 string.
   * VersionedTransaction uses .serialize() directly.
   * Legacy Transaction uses .serialize({requireAllSignatures: false, verifySignatures: false}).
   * Returns null if serialization fails.
   */
  function serializeSolanaTx(transaction) {
    try {
      let bytes;
      if (transaction && transaction.message && transaction.message.compiledInstructions) {
        bytes = transaction.serialize();
      } else if (transaction && Array.isArray(transaction.instructions)) {
        bytes = transaction.serialize({ requireAllSignatures: false, verifySignatures: false });
      }
      if (!bytes) return null;
      const u8 = new Uint8Array(bytes);
      return btoa(String.fromCharCode.apply(null, Array.from(u8)));
    } catch (_) {
      return null;
    }
  }

  /**
   * Patch a Solana-style provider (Phantom, Solflare, Backpack, window.solana).
   * Intercepts signAndSendTransaction and signTransaction.
   */
  function patchSolanaProvider(provider, name) {
    if (!provider || provider.__sentinelSolanaPatched) return;
    provider.__sentinelSolanaPatched = true;

    // ── signAndSendTransaction ──
    if (typeof provider.signAndSendTransaction === "function") {
      const origSignAndSend = provider.signAndSendTransaction.bind(provider);
      provider.signAndSendTransaction = async function (transaction, options) {
        const info = extractSolanaInfo(transaction);
        const requestId = ++requestIdCounter;
        const encodedTx = serializeSolanaTx(transaction);

        postIntercept("SOL_TX_INTERCEPT", {
          requestId,
          contractAddress: info.programId,
          txType: info.txType,
          chain: "solana",
          wallet: name,
          amountUsd: 0,
          encodedTx,
        });

        const decision = await waitForSentinelDecision(requestId);
        if (!decision.approved) {
          throw new Error("SentinelWallet: " + (decision.reason || "Solana transaction blocked by policy"));
        }

        return origSignAndSend(transaction, options);
      };
    }

    // ── signTransaction (single) ──
    if (typeof provider.signTransaction === "function") {
      const origSignTx = provider.signTransaction.bind(provider);
      provider.signTransaction = async function (transaction) {
        const info = extractSolanaInfo(transaction);
        const requestId = ++requestIdCounter;
        const encodedTx = serializeSolanaTx(transaction);

        postIntercept("SOL_TX_INTERCEPT", {
          requestId,
          contractAddress: info.programId,
          txType: "sign_" + info.txType,
          chain: "solana",
          wallet: name,
          amountUsd: 0,
          encodedTx,
        });

        const decision = await waitForSentinelDecision(requestId);
        if (!decision.approved) {
          throw new Error("SentinelWallet: " + (decision.reason || "Solana transaction blocked by policy"));
        }

        return origSignTx(transaction);
      };
    }

    // ── signAllTransactions (batch) ──
    if (typeof provider.signAllTransactions === "function") {
      const origSignAll = provider.signAllTransactions.bind(provider);
      provider.signAllTransactions = async function (transactions) {
        for (const tx of transactions) {
          const info = extractSolanaInfo(tx);
          const requestId = ++requestIdCounter;
          const encodedTx = serializeSolanaTx(tx);

          postIntercept("SOL_TX_INTERCEPT", {
            requestId,
            contractAddress: info.programId,
            txType: "batch_" + info.txType,
            chain: "solana",
            wallet: name,
            amountUsd: 0,
            encodedTx,
          });

          const decision = await waitForSentinelDecision(requestId);
          if (!decision.approved) {
            throw new Error("SentinelWallet: " + (decision.reason || "Solana batch transaction blocked by policy"));
          }
        }

        return origSignAll(transactions);
      };
    }
  }

  // ─────────────────────────────────────────────
  //  EVM HELPERS (MetaMask / EIP-1193)
  // ─────────────────────────────────────────────

  function patchEvmProvider(provider) {
    if (!provider || provider.__sentinelEvmPatched) return;
    provider.__sentinelEvmPatched = true;

    const origRequest = provider.request.bind(provider);

    provider.request = async function (args) {
      const { method, params } = args || {};

      // ── eth_sendTransaction ──
      if (method === "eth_sendTransaction" && params && params[0]) {
        const tx = params[0];
        const contractAddress = tx.to || null;
        const txType = tx.data && tx.data !== "0x" ? "contract_call" : "transfer";
        const requestId = ++requestIdCounter;

        postIntercept("TX_INTERCEPT", {
          requestId,
          contractAddress,
          txType,
          chain: "evm",
          amountUsd: 0,
        });

        const decision = await waitForSentinelDecision(requestId);
        if (!decision.approved) {
          throw new Error("SentinelWallet: " + (decision.reason || "EVM transaction blocked by policy"));
        }

        return origRequest(args);
      }

      // ── Token approval scan (non-blocking, advisory) ──
      if (
        (method === "eth_signTypedData_v4" || method === "eth_signTypedData_v3") &&
        params
      ) {
        try {
          const payload = params[1] ? JSON.parse(params[1]) : {};
          const spender = payload?.message?.spender || payload?.message?.to || null;
          if (spender) {
            postIntercept("CONTRACT_SCAN", { contractAddress: spender, chain: "evm" });
          }
        } catch (_) {}
      }

      return origRequest(args);
    };
  }

  // ─────────────────────────────────────────────
  //  ATTACH TO ALL SOLANA WALLETS
  // ─────────────────────────────────────────────

  function attachSolana() {
    // window.solana (Phantom legacy / generic)
    if (window.solana) patchSolanaProvider(window.solana, "Phantom/solana");

    // window.phantom.solana (Phantom modern)
    if (window.phantom && window.phantom.solana) {
      patchSolanaProvider(window.phantom.solana, "Phantom");
    }

    // window.solflare
    if (window.solflare) patchSolanaProvider(window.solflare, "Solflare");

    // window.backpack
    if (window.backpack) patchSolanaProvider(window.backpack, "Backpack");

    // window.glowSolana (Glow wallet)
    if (window.glowSolana) patchSolanaProvider(window.glowSolana, "Glow");
  }

  // Attach immediately for already-loaded wallets
  attachSolana();

  // Wallets may inject after DOMContentLoaded — also listen for their announcements
  window.addEventListener("message", (e) => {
    if (e.data && e.data.type === "wallet_connect") attachSolana();
  });

  // Re-check on DOM ready in case wallet injects late
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", attachSolana);
  }

  // Also watch for Phantom's lazy-inject pattern via defineProperty
  const _defineProperty = Object.defineProperty;
  Object.defineProperty = function (obj, prop, descriptor) {
    if (obj === window && (prop === "solana" || prop === "phantom" || prop === "solflare" || prop === "backpack")) {
      const result = _defineProperty(obj, prop, descriptor);
      // Give wallet time to finish setup before patching
      setTimeout(attachSolana, 0);
      return result;
    }
    return _defineProperty(obj, prop, descriptor);
  };

  // ─────────────────────────────────────────────
  //  ATTACH TO EVM (MetaMask)
  // ─────────────────────────────────────────────

  if (window.ethereum) {
    patchEvmProvider(window.ethereum);
  }

  const _origEthereum = window.ethereum;
  Object.defineProperty(window, "ethereum", {
    get() { return _origEthereum; },
    set(val) { patchEvmProvider(val); },
    configurable: true,
  });

})();
