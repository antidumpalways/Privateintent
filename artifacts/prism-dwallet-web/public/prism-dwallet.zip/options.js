const DEFAULT_API = "http://localhost:8080";
const DEFAULT_WALLET = "99pdEHxysxtd6KhFQ6im6NRAX5hHUm3rpMNJSCjUjfBQ";

const EVM_RE = /^0x[0-9a-fA-F]{40}$/;
const SOL_RE = /^[1-9A-HJ-NP-Za-km-z]{32,44}$/;

function validateWalletAddress(address) {
  if (!address) return "Wallet address is required.";
  if (EVM_RE.test(address)) return null;
  if (SOL_RE.test(address)) return null;
  if (address.startsWith("0x")) {
    return "Invalid EVM address — must be 0x followed by 40 hex characters.";
  }
  return "Invalid address — enter a Solana base58 address (32–44 chars) or an EVM 0x address.";
}

function setWalletError(msg) {
  const input = document.getElementById("wallet-address");
  const errorEl = document.getElementById("wallet-error");
  const saveBtn = document.getElementById("save-btn");

  if (msg) {
    errorEl.textContent = msg;
    input.classList.add("input--error");
    saveBtn.disabled = true;
  } else {
    errorEl.textContent = "";
    input.classList.remove("input--error");
    saveBtn.disabled = false;
  }
}

document.addEventListener("DOMContentLoaded", () => {
  chrome.storage.local.get(["apiBase", "walletAddress"], (items) => {
    document.getElementById("api-base").value = items.apiBase || DEFAULT_API;
    document.getElementById("wallet-address").value = items.walletAddress || DEFAULT_WALLET;
  });

  document.getElementById("wallet-address").addEventListener("input", (e) => {
    const address = e.target.value.trim();
    if (address === "") {
      setWalletError(null);
      return;
    }
    setWalletError(validateWalletAddress(address));
  });

  document.getElementById("save-btn").addEventListener("click", () => {
    const apiBase = document.getElementById("api-base").value.trim() || DEFAULT_API;
    const walletAddress = document.getElementById("wallet-address").value.trim();

    const error = validateWalletAddress(walletAddress || DEFAULT_WALLET);
    if (error) {
      setWalletError(error);
      return;
    }

    chrome.storage.local.set({ apiBase, walletAddress: walletAddress || DEFAULT_WALLET }, () => {
      const msg = document.getElementById("saved-msg");
      msg.style.display = "inline";
      setTimeout(() => { msg.style.display = "none"; }, 2500);
    });
  });
});
