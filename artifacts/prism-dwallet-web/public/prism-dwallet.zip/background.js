const DEFAULT_API = "https://sentinel-riharahap252.replit.app";
const DEFAULT_WALLET = "99pdEHxysxtd6KhFQ6im6NRAX5hHUm3rpMNJSCjUjfBQ";
const RISK_THRESHOLD = 70; // Aligned with content.js BLOCK_THRESHOLD
const CHECK_INTERVAL_MINUTES = 5;

async function getConfig() {
  return new Promise((resolve) => {
    chrome.storage.local.get(["apiBase", "walletAddress"], (items) => {
      resolve({
        apiBase: items.apiBase || DEFAULT_API,
        walletAddress: items.walletAddress || DEFAULT_WALLET,
      });
    });
  });
}

async function checkThreats() {
  const { apiBase, walletAddress } = await getConfig();
  try {
    const res = await fetch(`${apiBase}/api/dashboard/${walletAddress}`);
    if (!res.ok) return;
    const data = await res.json();

    if (data.threatsBlockedToday > 0) {
      chrome.action.setBadgeText({ text: String(data.threatsBlockedToday) });
      chrome.action.setBadgeBackgroundColor({ color: "#ef4444" });
    } else {
      chrome.action.setBadgeText({ text: "" });
    }
  } catch {
    chrome.action.setBadgeText({ text: "!" });
    chrome.action.setBadgeBackgroundColor({ color: "#f59715" });
  }
}

chrome.alarms.create("prismCheck", { periodInMinutes: CHECK_INTERVAL_MINUTES });

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "prismCheck") {
    checkThreats();
  }
});

chrome.runtime.onInstalled.addListener(() => {
  checkThreats();
});

function saveLastScanResult(contractAddress, data, source) {
  chrome.storage.local.set({
    lastScanResult: {
      contractAddress,
      score: data.score ?? 0,
      verdict: data.verdict ?? "safe",
      summary: data.summary ?? "",
      flags: data.flags ?? [],
      forensicAnalysis: data.forensicAnalysis ?? null,
      ikaCoSigned: data.ikaCoSigned ?? false,
      ikaMode: data.ika?.mode ?? data.ikaMode ?? "devnet",
      source, // "scan" | "analyze"
      ts: Date.now(),
    },
  });
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type === "SCAN_CONTRACT") {
    (async () => {
      const { apiBase } = await getConfig();
      try {
        const res = await fetch(`${apiBase}/api/risk/scan/${encodeURIComponent(msg.contractAddress)}`);
        if (!res.ok) {
          sendResponse({ error: "Scan failed" });
          return;
        }
        const data = await res.json();
        saveLastScanResult(msg.contractAddress, data, "scan");
        sendResponse({ result: data });
      } catch (err) {
        sendResponse({ error: String(err) });
      }
    })();
    return true;
  }

  if (msg.type === "ANALYZE_TX") {
    (async () => {
      const { apiBase, walletAddress } = await getConfig();
      try {
        const analyzePayload = {
          walletAddress,
          contractAddress: msg.contractAddress,
          txAmountUsd: msg.amountUsd || 0,
          txType: msg.txType || "unknown",
        };
        if (msg.encodedTx) {
          analyzePayload.encodedTx = msg.encodedTx;
        }
        const res = await fetch(`${apiBase}/api/risk/analyze`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(analyzePayload),
        });
        if (!res.ok) {
          sendResponse({ error: "Analysis failed" });
          return;
        }
        const data = await res.json();
        const isHighRisk = (data.score || 0) >= RISK_THRESHOLD;
        saveLastScanResult(msg.contractAddress, data, "analyze");
        sendResponse({
          result: data,
          isHighRisk,
          ikaMode: data.ika?.mode || "devnet",
          encryptRef: data.encrypt?.ref || "",
        });
      } catch (err) {
        sendResponse({ error: String(err) });
      }
    })();
    return true;
  }
});
